﻿
namespace WcfService
{
    public class InventoryService : IInventoryService
    {
        public Inventory GetInventory(string barcode)
        {
            return new Inventory { barcode = barcode, price = "300.50" };
        }
    }
}
