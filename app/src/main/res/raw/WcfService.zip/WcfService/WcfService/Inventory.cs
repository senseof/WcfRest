﻿
namespace WcfService
{
    public class Inventory
    {
        public string barcode { get; set; }
        public string price { get; set; }
    }
}