﻿using System.ServiceModel;
using System.ServiceModel.Web;

namespace WcfService
{
    [ServiceContract]
    public interface IInventoryService
    {
        [OperationContract]
        [WebGet(UriTemplate = "Inventory/{barcode}")]
        Inventory GetInventory(string barcode);
    }
}

